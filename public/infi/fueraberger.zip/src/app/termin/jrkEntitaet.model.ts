export class jrkEntitaet {
public id:number;
public name:String;
public ort:String;
public typ:any;
public termine:Object;
public jrkEntitaet:Object;
public jrkentitaet1:Object;
public persons:Object;
public persons1:Object;
  
constructor(id: number, name: string,ort:string) {
this.id = id;
this.name = name;
this.ort=ort;
}
}