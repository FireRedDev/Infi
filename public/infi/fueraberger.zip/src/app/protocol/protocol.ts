export class Protokoll{
    
constructor(
public vzeit= 0,
public kinderliste=[],
public betreuer=[],
public taetigkeiten='',
public kategorie='Soziales'
)
{}

}
