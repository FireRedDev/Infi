export var single = [
  ];
  
  export var multi = [
  ];
  export var single2 = [
    {
      "name": "",
      "value": 0
    }
  ];
  
export var multi2 = [
{
"name": "Germany",
"series": [
{
"name": "2010",
"value": 7300000
},
{
"name": "2011",
"value": 8940000
}
]
},
  
{
"name": "USA",
"series": [
{
"name": "2010",
"value": 7870000
},
{
"name": "2011",
"value": 8270000
}
]
},
  
{
"name": "France",
"series": [
{
"name": "2010",
"value": 5000002
},
{
"name": "2011",
"value": 5800000
}
]
}
];

export var singleChart = [
{
"name": "works",
"value": 5
}
];
  
export var multiChart = [
{
"name": "Germany",
"series": [
{
"name": "2010",
"value": 7300000
},
{
"name": "2011",
"value": 8940000
}
]
},
  
{
"name": "USA",
"series": [
{
"name": "2010",
"value": 7870000
},
{
"name": "2011",
"value": 8270000
}
]
},
  
{
"name": "France",
"series": [
{
"name": "2010",
"value": 5000002
},
{
"name": "2011",
"value": 5800000
}
]
}
];

export var singleChartBar = [
{
"name": "Jannuar",
"value": 1000
},
{
"name": "Februar",
"value": 5000
},
{
"name": "März",
"value": 4700
},
{
"name": "April",
"value": 4300
},
{
"name": "Mai",
"value": 5200
},
{
"name": "Juni",
"value": 7200
},
{
"name": "Juli",
"value": 5500
},
{
"name": "August",
"value": 2000
},
{
"name": "September",
"value": 1234
},
{
"name": "Oktober",
"value": 2345
},
{
"name": "November",
"value": 3456
},
{
"name": "Dezember",
"value": 3000
}
];
    
export var multiChartBar = [
{
"name": "Jannuar",
"value": 1000
},
{
"name": "Februar",
"value": 5000
},
{
"name": "März",
"value": 4700
},
{
"name": "April",
"value": 4300
},
{
"name": "Mai",
"value": 5200
},
{
"name": "Juni",
"value": 7200
},
{
"name": "Juli",
"value": 5500
},
{
"name": "August",
"value": 2000
},
{
"name": "September",
"value": 1234
},
{
"name": "Oktober",
"value": 2345
},
{
"name": "November",
"value": 3456
},
{
"name": "Dezember",
"value": 3000
}
];


export var single3 = [
{
"name": "Germany",
"value": 8940000
},
{
"name": "USA",
"value": 5000000
},
{
"name": "France",
"value": 7200000
}
];
    
export var multi3 = [
{
"name": "Germany",
"series": [
{
"name": "2010",
"value": 7300000
},
{
"name": "2011",
"value": 8940000
}
]
},
    
{
"name": "USA",
"series": [
{
"name": "2010",
"value": 7870000
},
{
"name": "2011",
"value": 8270000
}
]
},
    
{
"name": "France",
"series": [
{
"name": "2010",
"value": 5000002
},
{
"name": "2011",
"value": 5800000
}
]
}
];
    